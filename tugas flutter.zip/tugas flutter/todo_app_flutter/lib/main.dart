import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Todo App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: TodoListPage(),
    );
  }
}

class Task {
  int? id;
  String title;
  String priority; // 'low'|'medium'|'high'
  DateTime dueDate;
  String isDone; // 'true'|'false'

  Task({
    this.id,
    required this.title,
    required this.priority,
    required this.dueDate,
    this.isDone = 'false',
  });

  factory Task.fromJson(Map<String, dynamic> j) {
    return Task(
      id: j['id'] != null ? int.parse(j['id'].toString()) : null,
      title: j['title'] ?? '',
      priority: j['priority'] ?? 'low',
      dueDate: DateTime.parse(j['due_date']),
      isDone: j['is_done'] ?? 'false',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'title': title,
      'priority': priority,
      'due_date': DateFormat('yyyy-MM-dd HH:mm:ss').format(dueDate),
      'is_done': isDone,
    };
  }
}

class Api {
 
  static const String baseUrl = 'http://localhost/todo_app/tasks/';

  static Future<List<Task>> fetchTasks() async {
    final res = await http.get(Uri.parse(baseUrl + 'get_task.php'));
    if (res.statusCode == 200) {
      final jsonBody = jsonDecode(res.body);
      if (jsonBody['status'] == 'success') {
        final List data = jsonBody['data'];
        return data.map((e) => Task.fromJson(e)).toList();
      }
    }
    throw Exception('Gagal mengambil data tugas');
  }

  static Future<bool> addTask(Task t) async {
    final res = await http.post(
      Uri.parse(baseUrl + 'add_task.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(t.toJson()),
    );
    if (res.statusCode == 200) {
      final js = jsonDecode(res.body);
      return js['status'] == 'success';
    }
    return false;
  }

  static Future<bool> updateTask(Task t) async {
    final res = await http.post(
      Uri.parse(baseUrl + 'update_task.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(t.toJson()),
    );
    if (res.statusCode == 200) {
      final js = jsonDecode(res.body);
      return js['status'] == 'success';
    }
    return false;
  }

  static Future<bool> deleteTask(int id) async {
    final res = await http.post(
      Uri.parse(baseUrl + 'delete_task.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'id': id}),
    );
    if (res.statusCode == 200) {
      final js = jsonDecode(res.body);
      return js['status'] == 'success';
    }
    return false;
  }
}

class TodoListPage extends StatefulWidget {
  @override
  _TodoListPageState createState() => _TodoListPageState();
}

class _TodoListPageState extends State<TodoListPage> {
  List<Task> tasks = [];
  bool loading = false;

  Future<void> loadTasks() async {
    setState(() => loading = true);
    try {
      final list = await Api.fetchTasks();
      list.sort((a, b) => a.dueDate.compareTo(b.dueDate));
      setState(() {
        tasks = list;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    loadTasks();
  }

  void openForm({Task? task}) async {
    final updated = await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => TaskFormPage(task: task)),
    );
    if (updated == true) {
      loadTasks();
    }
  }

  void confirmDelete(Task t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Hapus tugas?'),
        content: Text('Yakin ingin menghapus "${t.title}"?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: Text('Hapus')),
        ],
      ),
    );
    if (ok == true) {
      final success = await Api.deleteTask(t.id!);
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tugas dihapus')));
        loadTasks();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menghapus tugas')));
      }
    }
  }

  Widget _buildTile(Task t) {
    final due = DateFormat('yyyy-MM-dd HH:mm').format(t.dueDate);
    return Dismissible(
      key: ValueKey(t.id),
      background: Container(color: Colors.red, alignment: Alignment.centerLeft, padding: EdgeInsets.only(left: 16), child: Icon(Icons.delete, color: Colors.white)),
      direction: DismissDirection.startToEnd,
      confirmDismiss: (_) async {
        await Future.delayed(Duration(milliseconds: 1));
        confirmDelete(t);
        return false;
      },
      child: ListTile(
        leading: Checkbox(
          value: t.isDone == 'true',
          onChanged: (v) async {
            t.isDone = v == true ? 'true' : 'false';
            final ok = await Api.updateTask(t);
            if (ok) loadTasks();
          },
        ),
        title: Text(t.title, style: TextStyle(decoration: t.isDone == 'true' ? TextDecoration.lineThrough : null)),
        subtitle: Text('Priority: ${t.priority}  •  Due: $due'),
        trailing: IconButton(icon: Icon(Icons.edit), onPressed: () => openForm(task: t)),
        onTap: () => openForm(task: t),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Todo App'),
        actions: [IconButton(icon: Icon(Icons.refresh), onPressed: loadTasks)],
      ),
      body: loading
          ? Center(child: CircularProgressIndicator())
          : tasks.isEmpty
              ? Center(child: Text('Tidak ada tugas. Tekan + untuk tambah.'))
              : RefreshIndicator(
                  onRefresh: loadTasks,
                  child: ListView.separated(
                    itemBuilder: (_, i) => _buildTile(tasks[i]),
                    separatorBuilder: (_, i) => Divider(height: 1),
                    itemCount: tasks.length,
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => openForm(),
        child: Icon(Icons.add),
      ),
    );
  }
}

class TaskFormPage extends StatefulWidget {
  final Task? task;
  TaskFormPage({this.task});

  @override
  _TaskFormPageState createState() => _TaskFormPageState();
}

class _TaskFormPageState extends State<TaskFormPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  String _priority = 'low';
  DateTime _due = DateTime.now().add(Duration(hours: 1));
  bool _isSaving = false;
  bool _isDone = false;

  @override
  void initState() {
    super.initState();
    if (widget.task != null) {
      _titleCtrl.text = widget.task!.title;
      _priority = widget.task!.priority;
      _due = widget.task!.dueDate;
      _isDone = widget.task!.isDone == 'true';
    }
  }

  Future<void> _pickDateTime() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _due,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (d == null) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_due));
    if (t == null) return;
    setState(() {
      _due = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);

    final task = Task(
      id: widget.task?.id,
      title: _titleCtrl.text.trim(),
      priority: _priority,
      dueDate: _due,
      isDone: _isDone ? 'true' : 'false',
    );

    bool ok = false;
    if (widget.task == null) {
      ok = await Api.addTask(task);
    } else {
      ok = await Api.updateTask(task);
    }

    setState(() => _isSaving = false);
    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Berhasil disimpan')));
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menyimpan')));
    }
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dueStr = DateFormat('yyyy-MM-dd HH:mm').format(_due);
    return Scaffold(
      appBar: AppBar(title: Text(widget.task == null ? 'Tambah Tugas' : 'Edit Tugas')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _titleCtrl,
                decoration: InputDecoration(labelText: 'Judul'),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Judul harus diisi' : null,
              ),
              SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _priority,
                items: ['low', 'medium', 'high'].map((p) => DropdownMenuItem(value: p, child: Text(p))).toList(),
                onChanged: (v) => setState(() => _priority = v ?? 'low'),
                decoration: InputDecoration(labelText: 'Priority'),
              ),
              SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('Due: $dueStr'),
                trailing: Icon(Icons.calendar_today),
                onTap: _pickDateTime,
              ),
              SizedBox(height: 12),
              if (widget.task != null)
                SwitchListTile(
                  title: Text('Selesai'),
                  value: _isDone,
                  onChanged: (v) => setState(() => _isDone = v),
                ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isSaving ? null : _save,
                child: _isSaving ? CircularProgressIndicator(color: Colors.white) : Text('Simpan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
