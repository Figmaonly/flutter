<?php
require_once "../config/db.php";

$data = json_decode(file_get_contents("php://input"), true);

$id = $data['id'] ?? '';
$title = $data['title'] ?? '';
$priority = $data['priority'] ?? 'low';
$due_date = $data['due_date'] ?? '';
$is_done = $data['is_done'] ?? 'false';

if (!$id) {
    echo json_encode(["status" => "error", "message" => "ID tidak ditemukan"]);
    exit;
}

$sql = "UPDATE tasks SET title=?, priority=?, due_date=?, is_done=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssi", $title, $priority, $due_date, $is_done, $id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Tugas berhasil diupdate"]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal update tugas"]);
}
?>
