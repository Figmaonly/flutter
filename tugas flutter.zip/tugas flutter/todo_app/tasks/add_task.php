<?php
require_once "../config/cors.php";
require_once "../config/db.php";

$data = json_decode(file_get_contents("php://input"), true);

$title = trim($data['title'] ?? '');
$priority = $data['priority'] ?? 'low';
$due_date = $data['due_date'] ?? '';

if ($title === '' || $due_date === '') {
    echo json_encode(["status" => "error", "message" => "Data tidak lengkap"]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO tasks (title, priority, due_date) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $title, $priority, $due_date);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Tugas berhasil ditambahkan",
        "id" => $conn->insert_id
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal menambahkan tugas"]);
}
