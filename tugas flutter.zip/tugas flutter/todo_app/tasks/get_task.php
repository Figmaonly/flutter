<?php
require_once "../config/db.php";

$sql = "SELECT * FROM tasks ORDER BY due_date ASC";
$result = $conn->query($sql);

$tasks = [];
while ($row = $result->fetch_assoc()) {
    $tasks[] = $row;
}

echo json_encode([
    "status" => "success",
    "data" => $tasks
]);
?>
